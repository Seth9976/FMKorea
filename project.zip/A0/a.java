package a0;

public abstract class a {
}


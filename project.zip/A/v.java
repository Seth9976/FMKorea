package A;

public abstract class v {
}


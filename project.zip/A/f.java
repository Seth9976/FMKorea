package A;

public abstract class f {
    public static final int a = 0x7F0C00A0;  // layout:splash_screen_view

}


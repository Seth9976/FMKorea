package A;

public abstract class n {
}


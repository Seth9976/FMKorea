package A;

public final class h implements d {
    // 去混淆评级： 低(20)
    @Override  // A.g$d
    public final boolean a() {
        return false;
    }
}


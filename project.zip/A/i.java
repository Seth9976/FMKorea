package A;

public final class i implements Runnable {
    public final s f;
    public final e g;

    public i(s s0, e g$e0) {
        this.f = s0;
        this.g = g$e0;
    }

    @Override
    public final void run() {
        b.f(this.f, this.g);
    }
}


package A;

public abstract class d {
    public static final int a = 0x7F0800DF;  // drawable:icon_background

}


package A;

import android.view.WindowInsets.Builder;

public abstract class j {
    public static WindowInsets.Builder a() {
        return new WindowInsets.Builder();
    }
}


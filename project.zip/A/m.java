package A;

public abstract class m {
}


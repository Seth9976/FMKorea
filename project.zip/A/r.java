package A;

import android.window.SplashScreenView;

public abstract class r {
    public static SplashScreenView a(Object object0) [...] // Inlined contents
}


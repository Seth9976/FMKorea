package a;

abstract class c {
}


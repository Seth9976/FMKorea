package A;

public abstract class k {
}


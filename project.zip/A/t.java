package A;

public abstract class t {
}


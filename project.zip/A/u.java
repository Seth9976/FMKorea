package A;

public abstract class u {
}


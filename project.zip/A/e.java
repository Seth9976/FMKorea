package A;

public abstract class e {
    public static final int a = 0x7F0901BE;  // id:splashscreen_icon_view

}


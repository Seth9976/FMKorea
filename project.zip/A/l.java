package A;

public abstract class l {
}


package a;

public final class a {
    // 去混淆评级： 低(20)
    public final StackTraceElement a() {
        return b.b(new Exception(), "c");
    }
}


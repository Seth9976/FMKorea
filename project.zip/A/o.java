package A;

public abstract class o {
}


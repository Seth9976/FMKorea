package A;

import android.window.SplashScreenView;

public abstract class q {
    public static boolean a(Object object0) {
        return object0 instanceof SplashScreenView;
    }
}


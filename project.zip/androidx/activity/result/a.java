package androidx.activity.result;

public interface a {
    void a(Object arg1);
}


package androidx.activity.result;

public interface c {
    ActivityResultRegistry D();
}


package androidx.activity.result;

import androidx.core.app.c;

public abstract class b {
    public void a(Object object0) {
        this.b(object0, null);
    }

    public abstract void b(Object arg1, c arg2);

    public abstract void c();
}


package androidx.activity;

import androidx.lifecycle.n;

public interface x extends n {
    OnBackPressedDispatcher f();
}


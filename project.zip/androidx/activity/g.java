package androidx.activity;

import android.content.Context;
import c.b;

public final class g implements b {
    public final ComponentActivity a;

    public g(ComponentActivity componentActivity0) {
        this.a = componentActivity0;
    }

    @Override  // c.b
    public final void a(Context context0) {
        this.a.G0(context0);
    }
}


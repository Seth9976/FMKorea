package androidx.activity;

public final class j implements Runnable {
    public final k f;

    public j(k k0) {
        this.f = k0;
    }

    @Override
    public final void run() {
        k.d(this.f);
    }
}


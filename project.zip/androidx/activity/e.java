package androidx.activity;

import y3.a;

public final class e implements a {
    public final ComponentActivity f;

    public e(ComponentActivity componentActivity0) {
        this.f = componentActivity0;
    }

    @Override  // y3.a
    public final Object a() {
        return this.f.E0();
    }
}


package androidx.activity;

public abstract class y {
    public static final int a = 0x7F09018D;  // id:report_drawn
    public static final int b = 0x7F090214;  // id:view_tree_on_back_pressed_dispatcher_owner

}


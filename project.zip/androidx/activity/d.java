package androidx.activity;

public final class d implements Runnable {
    public final ComponentActivity f;

    public d(ComponentActivity componentActivity0) {
        this.f = componentActivity0;
    }

    @Override
    public final void run() {
        this.f.D0();
    }
}


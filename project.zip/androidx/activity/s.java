package androidx.activity;

public final class s implements Runnable {
    public final t f;

    public s(t t0) {
        this.f = t0;
    }

    @Override
    public final void run() {
        t.d(this.f);
    }
}


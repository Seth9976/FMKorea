package androidx.activity;

public final class h implements Runnable {
    public final g f;

    public h(g componentActivity$g0) {
        this.f = componentActivity$g0;
    }

    @Override
    public final void run() {
        this.f.c();
    }
}


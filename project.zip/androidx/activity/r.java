package androidx.activity;

import android.view.View;
import android.view.Window;

interface r {
    void a(z arg1, z arg2, Window arg3, View arg4, boolean arg5, boolean arg6);
}


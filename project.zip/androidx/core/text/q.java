package androidx.core.text;

import android.text.TextUtils;
import java.util.Locale;

public abstract class q {
    public static int a(Locale locale0) {
        return TextUtils.getLayoutDirectionFromLocale(locale0);
    }
}


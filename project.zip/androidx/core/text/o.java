package androidx.core.text;

public interface o {
    boolean a(CharSequence arg1, int arg2, int arg3);
}


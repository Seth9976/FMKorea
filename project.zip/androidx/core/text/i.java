package androidx.core.text;

public abstract class i {
}


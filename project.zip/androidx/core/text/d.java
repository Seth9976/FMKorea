package androidx.core.text;

import android.text.PrecomputedText.Params.Builder;
import android.text.TextPaint;

public abstract class d {
    public static PrecomputedText.Params.Builder a(TextPaint textPaint0) {
        return new PrecomputedText.Params.Builder(textPaint0);
    }
}


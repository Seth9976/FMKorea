package androidx.core.graphics.drawable;

import android.graphics.drawable.Drawable;

public interface b {
    void a(Drawable arg1);

    Drawable b();
}


package androidx.core.app;

import B.a;

public interface r {
    void B(a arg1);

    void g0(a arg1);
}


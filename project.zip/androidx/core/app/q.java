package androidx.core.app;

import B.a;

public interface q {
    void K(a arg1);

    void o0(a arg1);
}


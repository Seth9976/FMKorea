package androidx.core.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

public interface k {
    ColorStateList getSupportButtonTintList();

    void setSupportButtonTintList(ColorStateList arg1);

    void setSupportButtonTintMode(PorterDuff.Mode arg1);
}


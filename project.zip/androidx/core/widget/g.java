package androidx.core.widget;

import android.widget.ListView;

public abstract class g {
    public static boolean a(ListView listView0, int v) {
        return listView0.canScrollList(v);
    }
}


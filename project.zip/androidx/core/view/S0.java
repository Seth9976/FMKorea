package androidx.core.view;

import android.graphics.Insets;
import android.view.WindowInsetsAnimation.Bounds;

public abstract class s0 {
    public static WindowInsetsAnimation.Bounds a(Insets insets0, Insets insets1) {
        return new WindowInsetsAnimation.Bounds(insets0, insets1);
    }
}


package androidx.core.view;

import android.content.Context;
import android.view.MotionEvent;

public final class m implements b {
    @Override  // androidx.core.view.o$b
    public final void a(Context context0, int[] arr_v, MotionEvent motionEvent0, int v) {
        o.c(context0, arr_v, motionEvent0, v);
    }
}


package androidx.core.view;

import android.view.PointerIcon;

public abstract class W {
    public static PointerIcon a(Object object0) [...] // Inlined contents
}


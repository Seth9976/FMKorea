package androidx.core.view;

public interface p {
    boolean a(float arg1);

    float b();

    void c();
}


package androidx.core.view;

public abstract class t0 {
    public static void a() {
    }
}


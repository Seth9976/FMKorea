package androidx.core.view;

import android.view.MotionEvent;
import android.view.VelocityTracker;

public final class n implements a {
    @Override  // androidx.core.view.o$a
    public final float a(VelocityTracker velocityTracker0, MotionEvent motionEvent0, int v) {
        return o.f(velocityTracker0, motionEvent0, v);
    }
}


package androidx.core.view;

import android.view.ContentInfo;

public abstract class c {
    public static ContentInfo a(Object object0) [...] // Inlined contents
}


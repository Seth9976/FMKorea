package androidx.core.view;

import android.view.LayoutInflater.Factory2;
import android.view.LayoutInflater;

public abstract class u {
    public static void a(LayoutInflater layoutInflater0, LayoutInflater.Factory2 layoutInflater$Factory20) {
        layoutInflater0.setFactory2(layoutInflater$Factory20);
    }
}


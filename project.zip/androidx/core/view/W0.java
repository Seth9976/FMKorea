package androidx.core.view;

import android.view.WindowInsetsAnimation;

public abstract class w0 {
    public static WindowInsetsAnimation a(Object object0) {
        return (WindowInsetsAnimation)object0;
    }
}


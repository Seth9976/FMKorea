package androidx.core.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public interface z {
    boolean a(MenuItem arg1);

    void b(Menu arg1);

    void c(Menu arg1, MenuInflater arg2);

    void d(Menu arg1);
}


package androidx.core.content;

import B.a;

public interface c {
    void a0(a arg1);

    void m(a arg1);
}


package androidx.core.content;

import B.a;

public interface b {
    void A(a arg1);

    void t(a arg1);
}


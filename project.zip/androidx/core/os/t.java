package androidx.core.os;

import android.os.OutcomeReceiver;
import p3.f;

public abstract class t {
    public static final OutcomeReceiver a(f f0) {
        return s.a(new androidx.core.os.f(f0));
    }
}


package androidx.core.os;

import java.util.Locale;

interface k {
    String a();

    Object b();

    Locale get(int arg1);

    boolean isEmpty();

    int size();
}


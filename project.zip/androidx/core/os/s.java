package androidx.core.os;

import android.os.OutcomeReceiver;

public abstract class s {
    public static OutcomeReceiver a(Object object0) {
        return (OutcomeReceiver)object0;
    }
}


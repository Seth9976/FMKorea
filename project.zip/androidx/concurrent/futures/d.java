package androidx.concurrent.futures;

public final class d extends a {
    @Override  // androidx.concurrent.futures.a
    public boolean r(Object object0) {
        return super.r(object0);
    }

    @Override  // androidx.concurrent.futures.a
    public boolean s(Throwable throwable0) {
        return super.s(throwable0);
    }

    public static d v() {
        return new d();
    }
}


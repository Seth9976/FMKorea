package androidx.cardview.widget;

import android.graphics.drawable.Drawable;
import android.view.View;

interface b {
    void a(Drawable arg1);

    boolean b();

    boolean c();

    Drawable d();

    View e();

    void f(int arg1, int arg2, int arg3, int arg4);
}


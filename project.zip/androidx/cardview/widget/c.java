package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;

interface c {
    void a(b arg1, Context arg2, ColorStateList arg3, float arg4, float arg5, float arg6);

    void b(b arg1, float arg2);

    float c(b arg1);

    float d(b arg1);

    void e(b arg1);

    void f(b arg1, float arg2);

    float g(b arg1);

    ColorStateList h(b arg1);

    void i();

    float j(b arg1);

    float k(b arg1);

    void l(b arg1);

    void m(b arg1, ColorStateList arg2);

    void n(b arg1, float arg2);
}


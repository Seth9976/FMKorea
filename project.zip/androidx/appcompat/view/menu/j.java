package androidx.appcompat.view.menu;

import android.content.Context;
import android.os.Parcelable;

public interface j {
    public interface a {
        void b(e arg1, boolean arg2);

        boolean c(e arg1);
    }

    void b(e arg1, boolean arg2);

    void c(boolean arg1);

    boolean d();

    boolean e(e arg1, g arg2);

    boolean f(e arg1, g arg2);

    void g(a arg1);

    int getId();

    void h(Context arg1, e arg2);

    void i(Parcelable arg1);

    boolean k(m arg1);

    Parcelable l();
}


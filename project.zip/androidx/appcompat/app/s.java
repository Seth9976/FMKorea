package androidx.appcompat.app;

import android.window.OnBackInvokedDispatcher;

public abstract class s {
    public static OnBackInvokedDispatcher a(Object object0) [...] // Inlined contents
}


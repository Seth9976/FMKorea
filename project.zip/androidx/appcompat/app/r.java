package androidx.appcompat.app;

import android.window.OnBackInvokedCallback;

public abstract class r {
    public static OnBackInvokedCallback a(Object object0) [...] // Inlined contents
}


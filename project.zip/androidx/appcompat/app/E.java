package androidx.appcompat.app;

import androidx.appcompat.view.b.a;
import androidx.appcompat.view.b;

public interface e {
    b M(a arg1);

    void n(b arg1);

    void r(b arg1);
}


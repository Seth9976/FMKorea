package androidx.appcompat.widget;

public final class e0 implements Runnable {
    public final Toolbar f;

    public e0(Toolbar toolbar0) {
        this.f = toolbar0;
    }

    @Override
    public final void run() {
        this.f.z();
    }
}


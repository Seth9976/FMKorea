package androidx.appcompat.widget;

public final class j0 implements Runnable {
    public final k0 f;

    public j0(k0 k00) {
        this.f = k00;
    }

    @Override
    public final void run() {
        this.f.d();
    }
}


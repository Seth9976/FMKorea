package androidx.appcompat.widget;

public final class d0 implements Runnable {
    public final Toolbar f;

    public d0(Toolbar toolbar0) {
        this.f = toolbar0;
    }

    @Override
    public final void run() {
        this.f.e();
    }
}


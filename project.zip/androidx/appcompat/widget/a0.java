package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

public class a0 {
    public ColorStateList a;
    public PorterDuff.Mode b;
    public boolean c;
    public boolean d;

    void a() {
        this.a = null;
        this.d = false;
        this.b = null;
        this.c = false;
    }
}


package androidx.appcompat.widget;

public final class i0 implements Runnable {
    public final k0 f;

    public i0(k0 k00) {
        this.f = k00;
    }

    @Override
    public final void run() {
        this.f.e();
    }
}


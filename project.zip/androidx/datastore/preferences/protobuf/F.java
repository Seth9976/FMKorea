package androidx.datastore.preferences.protobuf;

public abstract class f {
    public abstract void a(byte[] arg1, int arg2, int arg3);
}


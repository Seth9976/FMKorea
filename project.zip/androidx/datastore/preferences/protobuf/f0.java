package androidx.datastore.preferences.protobuf;

interface f0 {
    e0 a(Class arg1);
}


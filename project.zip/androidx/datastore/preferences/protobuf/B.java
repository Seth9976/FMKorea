package androidx.datastore.preferences.protobuf;

public abstract class b implements X {
    private static final o a;

    static {
        b.a = o.b();
    }
}


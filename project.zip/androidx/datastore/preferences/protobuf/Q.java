package androidx.datastore.preferences.protobuf;

import androidx.appcompat.app.E;
import java.util.Map.Entry;

final class q extends p {
    @Override  // androidx.datastore.preferences.protobuf.p
    int a(Map.Entry map$Entry0) {
        E.a(map$Entry0.getKey());
        throw null;
    }

    @Override  // androidx.datastore.preferences.protobuf.p
    Object b(o o0, O o1, int v) {
        o0.a(o1, v);
        return null;
    }

    @Override  // androidx.datastore.preferences.protobuf.p
    s c(Object object0) {
        E.a(object0);
        throw null;
    }

    @Override  // androidx.datastore.preferences.protobuf.p
    s d(Object object0) {
        E.a(object0);
        throw null;
    }

    @Override  // androidx.datastore.preferences.protobuf.p
    boolean e(O o0) {
        return false;
    }

    @Override  // androidx.datastore.preferences.protobuf.p
    void f(Object object0) {
        this.c(object0).o();
    }

    @Override  // androidx.datastore.preferences.protobuf.p
    Object g(d0 d00, Object object0, o o0, s s0, Object object1, l0 l00) {
        E.a(object0);
        throw null;
    }

    @Override  // androidx.datastore.preferences.protobuf.p
    void h(d0 d00, Object object0, o o0, s s0) {
        E.a(object0);
        throw null;
    }

    @Override  // androidx.datastore.preferences.protobuf.p
    void i(g g0, Object object0, o o0, s s0) {
        E.a(object0);
        throw null;
    }

    @Override  // androidx.datastore.preferences.protobuf.p
    void j(s0 s00, Map.Entry map$Entry0) {
        E.a(map$Entry0.getKey());
        throw null;
    }
}


package androidx.datastore.preferences.protobuf;

interface e0 {
    void a(Object arg1, Object arg2);

    void b(Object arg1, d0 arg2, o arg3);

    void c(Object arg1);

    boolean d(Object arg1);

    void e(Object arg1, s0 arg2);

    boolean f(Object arg1, Object arg2);

    int g(Object arg1);

    Object h();

    int i(Object arg1);
}


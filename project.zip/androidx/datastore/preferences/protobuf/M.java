package androidx.datastore.preferences.protobuf;

public abstract class m {
}


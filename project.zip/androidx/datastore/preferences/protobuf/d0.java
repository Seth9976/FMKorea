package androidx.datastore.preferences.protobuf;

import java.util.List;
import java.util.Map;

interface d0 {
    g A();

    void B(List arg1);

    int C();

    void D(List arg1, e0 arg2, o arg3);

    boolean E();

    int F();

    void G(List arg1);

    void H(List arg1);

    void I(List arg1, e0 arg2, o arg3);

    long J();

    String K();

    void L(List arg1);

    Object M(e0 arg1, o arg2);

    Object a(e0 arg1, o arg2);

    void b(List arg1);

    long c();

    long d();

    void e(List arg1);

    void f(List arg1);

    void g(List arg1);

    int getTag();

    int h();

    boolean i();

    long j();

    void k(List arg1);

    int l();

    void m(List arg1);

    void n(List arg1);

    void o(List arg1);

    void p(List arg1);

    void q(Map arg1, a arg2, o arg3);

    int r();

    double readDouble();

    float readFloat();

    void s(List arg1);

    int t();

    long u();

    void v(List arg1);

    String w();

    int x();

    void y(List arg1);

    void z(List arg1);
}


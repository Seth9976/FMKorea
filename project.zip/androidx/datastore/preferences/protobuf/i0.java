package androidx.datastore.preferences.protobuf;

abstract class i0 implements M {
}


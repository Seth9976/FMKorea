package androidx.datastore.preferences.protobuf;

import java.util.Map.Entry;

abstract class p {
    abstract int a(Map.Entry arg1);

    abstract Object b(o arg1, O arg2, int arg3);

    abstract s c(Object arg1);

    abstract s d(Object arg1);

    abstract boolean e(O arg1);

    abstract void f(Object arg1);

    abstract Object g(d0 arg1, Object arg2, o arg3, s arg4, Object arg5, l0 arg6);

    abstract void h(d0 arg1, Object arg2, o arg3, s arg4);

    abstract void i(g arg1, Object arg2, o arg3, s arg4);

    abstract void j(s0 arg1, Map.Entry arg2);
}


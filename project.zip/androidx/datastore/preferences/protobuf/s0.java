package androidx.datastore.preferences.protobuf;

import java.util.List;
import java.util.Map;

interface s0 {
    public static enum a {
        ASCENDING,
        DESCENDING;

    }

    void A(int arg1, List arg2, boolean arg3);

    void B(int arg1, List arg2, boolean arg3);

    void C(int arg1, List arg2, boolean arg3);

    void D(int arg1, long arg2);

    void E(int arg1, float arg2);

    void F(int arg1);

    void G(int arg1, List arg2, boolean arg3);

    void H(int arg1, int arg2);

    void I(int arg1, List arg2, boolean arg3);

    void J(int arg1, List arg2, boolean arg3);

    void K(int arg1, List arg2, boolean arg3);

    void L(int arg1, androidx.datastore.preferences.protobuf.H.a arg2, Map arg3);

    void M(int arg1, int arg2);

    void N(int arg1, List arg2);

    void O(int arg1, Object arg2, e0 arg3);

    void a(int arg1, List arg2, boolean arg3);

    void b(int arg1, int arg2);

    void c(int arg1, Object arg2);

    void d(int arg1, int arg2);

    void e(int arg1, double arg2);

    void f(int arg1, List arg2, boolean arg3);

    void g(int arg1, List arg2, boolean arg3);

    void h(int arg1, long arg2);

    a i();

    void j(int arg1, List arg2, e0 arg3);

    void k(int arg1, List arg2);

    void l(int arg1, List arg2, e0 arg3);

    void m(int arg1, String arg2);

    void n(int arg1, long arg2);

    void o(int arg1, List arg2, boolean arg3);

    void p(int arg1, long arg2);

    void q(int arg1, boolean arg2);

    void r(int arg1, int arg2);

    void s(int arg1);

    void t(int arg1, int arg2);

    void u(int arg1, List arg2, boolean arg3);

    void v(int arg1, List arg2, boolean arg3);

    void w(int arg1, g arg2);

    void x(int arg1, long arg2);

    void y(int arg1, List arg2, boolean arg3);

    void z(int arg1, Object arg2, e0 arg3);
}


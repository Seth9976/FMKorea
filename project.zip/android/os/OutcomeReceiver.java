package android.os;

public interface OutcomeReceiver {
    static {
        throw new NoClassDefFoundError();
    }
}


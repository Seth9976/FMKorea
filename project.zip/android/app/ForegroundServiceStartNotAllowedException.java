package android.app;

import android.os.Parcelable;

public final class ForegroundServiceStartNotAllowedException extends ServiceStartNotAllowedException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}


package android.app.job;

public class JobServiceEngine {
    static {
        throw new NoClassDefFoundError();
    }
}


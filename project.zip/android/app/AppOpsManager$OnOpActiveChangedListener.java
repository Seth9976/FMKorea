package android.app;

public interface AppOpsManager.OnOpActiveChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}


package android.media;

public class AudioTrack.StreamEventCallback {
    static {
        throw new NoClassDefFoundError();
    }
}


package android.support.v4.media.session;

import android.media.session.MediaSession;

class MediaSessionCompatApi22 {
    public static void setRatingType(Object object0, int v) {
        ((MediaSession)object0).setRatingType(v);
    }
}


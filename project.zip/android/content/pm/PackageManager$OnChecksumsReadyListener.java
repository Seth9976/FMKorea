package android.content.pm;

public interface PackageManager.OnChecksumsReadyListener {
    static {
        throw new NoClassDefFoundError();
    }
}


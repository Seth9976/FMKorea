package android.telephony;

public class TelephonyCallback {
    static {
        throw new NoClassDefFoundError();
    }
}


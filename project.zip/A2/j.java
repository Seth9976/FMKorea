package a2;

import J2.h.a;
import android.content.Context;
import com.google.firebase.FirebaseCommonRegistrar;

public final class j implements a {
    @Override  // J2.h$a
    public final String a(Object object0) {
        return FirebaseCommonRegistrar.a(((Context)object0));
    }
}


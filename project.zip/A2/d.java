package a2;

public final class d implements a {
    public final e a;

    public d(e e0) {
        this.a = e0;
    }

    @Override  // a2.e$a
    public final void onBackgroundStateChanged(boolean z) {
        e.a(this.a, z);
    }
}


package a2;

public abstract class f {
}


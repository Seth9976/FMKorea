package a3;

final class a {
    private final byte[] a;
    private final byte[] b;

    a(byte[] arr_b, byte[] arr_b1) {
        this.a = arr_b;
        this.b = arr_b1;
    }

    public byte[] a() {
        return this.a;
    }

    public byte[] b() {
        return this.b;
    }
}

